package lol.candysmp.link;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.logging.Level;

public final class CandyWebsiteLink extends JavaPlugin {
    private String apiBase;
    private String pluginSecret;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        FileConfiguration config = getConfig();
        apiBase = trimTrailingSlash(config.getString("api-base-url", "https://www.candysmp.lol"));
        pluginSecret = config.getString("plugin-secret", "CHANGE_ME_TO_MATCH_BACKEND_PLUGIN_SECRET").trim();
        getLogger().info("CandySMP website-link plugin enabled.");
        if (!apiBase.startsWith("https://")) getLogger().warning("api-base-url is not HTTPS. Use HTTPS for a public website.");
        if (pluginSecret.isBlank() || pluginSecret.contains("CHANGE_ME")) {
            getLogger().warning("Set plugin-secret in plugins/CandyWebsiteLink/config.yml to the same PLUGIN_SECRET used by the website backend.");
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            send(sender, "§d§l✦ CANDYSMP WEBSITE §7— §fCommands");
            send(sender, "§d/website link §f<code> §7Connect the account from your website profile");
            send(sender, "§d/website status §fCheck your account-link status");
            send(sender, "§d/website unlink §fDisconnect your Minecraft account");
            return true;
        }
        if (!(sender instanceof Player player)) {
            send(sender, "§cRun this command in-game as a player.");
            return true;
        }
        String action = args[0].toLowerCase();
        if (action.equals("link")) {
            if (args.length != 2) { send(player, "§cUsage: §f/website link <code> §7— generate the code in your website profile first."); return true; }
            String code = args[1].trim().toUpperCase();
            if (!code.matches("[A-Z2-9]{8}")) { send(player, "§cThat code format is invalid. Generate a new 8-character code on the website."); return true; }
            send(player, "§dCandySMP §7» §fChecking your link code…");
            runRequest(player, "/api/minecraft/link", "{\"code\":\"" + escapeJson(code) + "\",\"uuid\":\"" + player.getUniqueId() + "\",\"username\":\"" + escapeJson(player.getName()) + "\"}", "link");
            return true;
        }
        if (action.equals("status")) {
            runRequest(player, "/api/minecraft/status", "{\"uuid\":\"" + player.getUniqueId() + "\"}", "status");
            return true;
        }
        if (action.equals("unlink")) {
            send(player, "§eFor safety, unlink your Minecraft account from your signed-in website profile.");
            send(player, "§7Open §fhttps://www.candysmp.lol §7→ Profile → Unlink Minecraft.");
            return true;
        }
        send(player, "§cUnknown subcommand. Use §f/website help§c.");
        return true;
    }

    private void runRequest(Player player, String endpoint, String json, String operation) {
        getServer().getScheduler().runTaskAsynchronously(this, () -> {
            ApiResult result = callApi(endpoint, json);
            getServer().getScheduler().runTask(this, () -> {
                if (result.status == 0) {
                    send(player, "§cCandySMP website API could not be reached. Please tell a staff member.");
                    getLogger().warning("Website API request failed: " + endpoint + " — " + result.message);
                    return;
                }
                if (result.status >= 200 && result.status < 300) {
                    if (operation.equals("link")) {
                        send(player, "§d§l✦ CANDYSMP §7» §aMinecraft account linked successfully!");
                        send(player, "§7Your website profile is now connected to §f" + player.getName() + "§7.");
                    } else if (operation.equals("status")) {
                        boolean linked = jsonBoolean(result.body, "linked");
                        if (linked) send(player, "§dCandySMP §7» §aYour Minecraft account is linked to website profile §f" + jsonString(result.body, "websiteHandle") + "§a.");
                        else send(player, "§dCandySMP §7» §eYour Minecraft account is not linked to a website profile yet.");
                    } else {
                        String message = jsonString(result.body, "message");
                        send(player, "§dCandySMP §7» §a" + (message.isBlank() ? "Minecraft account unlinked." : message));
                    }
                } else {
                    String message = jsonString(result.body, "error");
                    if (message.isBlank()) message = switch (result.status) {
                        case 400 -> "That link code is invalid or expired. Generate a new one on the website.";
                        case 401 -> "Website plugin authentication failed. Ask staff to check the plugin configuration.";
                        case 409 -> "This Minecraft account or website profile is already linked elsewhere.";
                        case 503 -> "Website account linking is not configured yet. Ask staff for help.";
                        default -> "The website rejected that request (HTTP " + result.status + ").";
                    };
                    send(player, "§cCandySMP §7» §c" + message);
                }
            });
        });
    }

    private ApiResult callApi(String endpoint, String json) {
        if (pluginSecret.isBlank() || pluginSecret.contains("CHANGE_ME")) return new ApiResult(0, "Set plugin-secret in config.yml.", "");
        HttpURLConnection connection = null;
        try {
            URI uri = URI.create(apiBase + endpoint);
            connection = (HttpURLConnection) uri.toURL().openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(6000);
            connection.setReadTimeout(6000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("X-CandySMP-Plugin-Key", pluginSecret);
            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
            int status = connection.getResponseCode();
            InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            String body = stream == null ? "" : readAll(stream);
            return new ApiResult(status, "", body);
        } catch (Exception exception) {
            getLogger().log(Level.WARNING, "Could not call website API at " + apiBase + endpoint, exception);
            return new ApiResult(0, exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage(), "");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String readAll(InputStream stream) throws Exception {
        try (InputStream in = stream; ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[2048];
            int length;
            while ((length = in.read(chunk)) != -1) {
                if (buffer.size() + length > 32768) throw new IllegalStateException("API response too large");
                buffer.write(chunk, 0, length);
            }
            return buffer.toString(StandardCharsets.UTF_8);
        }
    }
    private static String trimTrailingSlash(String value) {
        String result = value == null ? "" : value.trim();
        while (result.endsWith("/")) result = result.substring(0, result.length() - 1);
        return result;
    }
    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
    private static String jsonString(String json, String key) {
        String marker = "\"" + key + "\"";
        int p = json.indexOf(marker);
        if (p < 0) return "";
        p = json.indexOf(':', p + marker.length());
        if (p < 0) return "";
        p++;
        while (p < json.length() && Character.isWhitespace(json.charAt(p))) p++;
        if (p >= json.length() || json.charAt(p) != '"') return "";
        p++;
        StringBuilder out = new StringBuilder();
        boolean escaped = false;
        for (; p < json.length(); p++) {
            char c = json.charAt(p);
            if (escaped) {
                out.append(switch (c) { case 'n' -> '\n'; case 'r' -> '\r'; case 't' -> '\t'; default -> c; });
                escaped = false;
            } else if (c == '\\') escaped = true;
            else if (c == '"') break;
            else out.append(c);
        }
        return out.toString();
    }
    private static boolean jsonBoolean(String json, String key) {
        String marker = "\"" + key + "\"";
        int p = json.indexOf(marker);
        if (p < 0) return false;
        p = json.indexOf(':', p + marker.length());
        if (p < 0) return false;
        return json.substring(p + 1).trim().startsWith("true");
    }
    private static void send(CommandSender sender, String message) { sender.sendMessage(message); }
    private record ApiResult(int status, String message, String body) { }
}
