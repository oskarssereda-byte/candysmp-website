# CandySMP account portal + Minecraft account linking

This is a full-stack starter for CandySMP: dark website, account registration/login, profile page, one-time Minecraft link codes, backend API, and Paper plugin source/JAR.

## How account linking works

1. A player registers or signs in on `https://www.candysmp.lol`.
2. In their Profile, they click **Generate link code**. The 8-character code is stored as a hash and expires in 10 minutes.
3. In Minecraft, the player types `/website link ABCD1234` using that displayed code.
4. The Paper plugin sends the player's UUID and in-game name to the website API over HTTPS, using a server-only shared secret.
5. The website validates the one-time code and associates that Minecraft UUID with the signed-in website profile.

A code can be used once, and a website profile and Minecraft UUID can each only be linked to one another. The player's Minecraft password is never requested.

## Project contents

- `public/index.html` — dark CandySMP responsive website.
- `server.js` — Express API, session handling, registration/login, profile, link codes, and plugin API.
- A persistent Docker volume for `candysmp.sqlite` — created automatically at first launch; contains accounts, link codes, and sessions.
- `plugin/CandyWebsiteLink-1.0.0.jar` — prebuilt Paper plugin.
- `plugin/src/main/java/.../CandyWebsiteLink.java` — plugin source.
- `plugin/pom.xml` — source build definition using the Paper 1.21.11 API.
- `docker-compose.yml`, `Dockerfile`, `deploy/Caddyfile` — VPS deployment with automatic HTTPS.

## Important security/deployment notes

- This is a source package, **not a website already published online**. It needs a public Node.js/Docker host with persistent storage and HTTPS. The included test plugin JAR was compiled against local stubs matching the standard Paper/Bukkit method signatures used because this build environment could not download Paper API from its Maven repository; the source and `pom.xml` are included so it can be rebuilt against the actual Paper 1.21.11 API. Test it on a staging server before relying on it.
- Use the `www.candysmp.lol` subdomain for this app so you don't overwrite your existing Minecraft root-domain DNS records. The Caddy config is already set to `www.candysmp.lol`.
- You'll need to point the `www` DNS record to the public IP of the VPS that runs Docker. Keep the existing Minecraft A/SRV records unless you deliberately plan a DNS migration.
- The plugin secret must be identical in the site's `.env` and `plugins/CandyWebsiteLink/config.yml`. Generate a long random secret (for example, `openssl rand -hex 32`). Do not publish either file with a real secret.
- SQLite requires persistent disk storage. Do not run multiple app replicas against the same SQLite database. Back up the `data` directory securely.
- Use a real HTTPS URL. Never send website passwords or a plugin secret over plain HTTP.
- If the Minecraft server has `online-mode=false`, UUIDs aren't strong proof of real Java account ownership. Use a reputable authentication plugin and understand the risks before relying on linked accounts for permissions or rewards.
- This starter does not yet implement email verification or self-service password reset. Do not reuse passwords from other services; production sites should add email verification, password-reset flow, monitoring, and regular backups.

## VPS deployment (Docker + DNS)

1. Use a Linux VPS with a public IP, Docker Engine, and Docker Compose plugin. Allow inbound TCP ports 80 and 443 in the VPS firewall.
2. Copy this project folder to the VPS.
3. Create the environment file: `cp .env.example .env`.
4. Generate a secret with `openssl rand -hex 32`, then paste the same generated value into `.env` as `PLUGIN_SECRET=...` and later into the Paper plugin config. Replace `APP_URL` only if you plan to use a different HTTPS domain.
5. In Namecheap Advanced DNS, add/change only the `www` record to point to the VPS. For this Caddy setup, use an `A Record`, host `www`, value the VPS public IPv4, TTL automatic. Remove any conflicting `www` records only. Keep the root `@` and Minecraft `_minecraft._tcp` SRV records unchanged.
6. Wait for DNS to resolve, then run `docker compose up -d --build` from this folder. Caddy obtains the HTTPS certificate automatically once DNS and ports 80/443 are correct.
7. Open `https://www.candysmp.lol` and create a test account. `https://www.candysmp.lol/api/health` should return `{"ok":true,...}`.
8. To view logs: `docker compose logs -f app caddy`. Back up the SQLite database regularly; from the project directory, copy it out of the container with `docker cp "$(docker compose ps -q app):/app/data/candysmp.sqlite" ./candysmp-backup.sqlite`.

If your hosting provider already gives your site an HTTPS hostname and doesn't support Docker/VPS access, deploy the Node app and a persistent disk following that host's instructions, set `PLUGIN_SECRET`, then point the plugin's `api-base-url` to the app's public HTTPS origin.

## Paper 1.21.11 plugin installation

1. Do not use PlugMan. Stop the server fully.
2. Upload `plugin/CandyWebsiteLink-1.0.0.jar` into the Minecraft server's `plugins` folder.
3. Start the server once, then stop it. This creates `plugins/CandyWebsiteLink/config.yml`.
4. Set `api-base-url: "https://www.candysmp.lol"` and set `plugin-secret` to the exact same random value used in the website's `.env` file.
5. Start the server normally. In game, use `/website help`.
6. On the website profile click **Generate link code**, then type `/website link THECODE` in Minecraft. Use `/website status` to check status. To unlink, sign into the website and use Profile → Unlink Minecraft.

If the plugin reports API authentication failure, the secrets don't match. If it cannot connect, check HTTPS/DNS/firewall and the server console logs.

## Local development

- Install Node.js 20+.
- Copy `.env.example` to `.env`; set a random `PLUGIN_SECRET`.
- Run `npm install`, then `npm start`.
- Open `http://localhost:3000`. For local development only, `NODE_ENV=development` allows the non-Secure session cookie over localhost HTTP. For the Minecraft plugin, use the public HTTPS URL, not localhost.

## Plugin rebuild

From `plugin/`, run `mvn package` with Java 21 installed and network access to the Paper Maven repository. The build output is `target/CandyWebsiteLink-1.0.0.jar`.
