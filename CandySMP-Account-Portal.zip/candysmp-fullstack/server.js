'use strict';
require('dotenv').config();
const express = require('express');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || 'development';
const COOKIE_NAME = 'candysmp_session';
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const CODE_TTL_MS = 10 * 60 * 1000;
const PLUGIN_SECRET = process.env.PLUGIN_SECRET || '';
const dataDir = path.resolve(process.env.DATA_DIR || './data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'candysmp.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  handle TEXT NOT NULL COLLATE NOCASE UNIQUE,
  email TEXT NOT NULL COLLATE NOCASE UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  minecraft_uuid TEXT UNIQUE,
  minecraft_username TEXT
);
CREATE TABLE IF NOT EXISTS browser_sessions (
  sid_hash TEXT PRIMARY KEY,
  account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
  csrf_token TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS link_codes (
  code_hash TEXT PRIMARY KEY,
  account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON browser_sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_codes_user ON link_codes(account_id);
`);

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (NODE_ENV === 'production') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
app.use(express.json({ limit: '24kb', type: 'application/json' }));

function sha256(value) { return crypto.createHash('sha256').update(String(value)).digest('hex'); }
function constantTimeEqual(a, b) {
  const aa = Buffer.from(String(a || ''), 'utf8');
  const bb = Buffer.from(String(b || ''), 'utf8');
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const ix = part.indexOf('=');
    if (ix > -1) out[part.slice(0, ix).trim()] = decodeURIComponent(part.slice(ix + 1).trim());
  }
  return out;
}
function setSessionCookie(res, sid) {
  const secure = NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=${encodeURIComponent(sid)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}${secure}`);
}
function clearSessionCookie(res) {
  const secure = NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`);
}
function newSession(accountId = null) {
  const sid = crypto.randomBytes(32).toString('hex');
  const sidHash = sha256(sid);
  const csrfToken = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  db.prepare('INSERT INTO browser_sessions (sid_hash, account_id, csrf_token, created_at, expires_at) VALUES (?, ?, ?, ?, ?)')
    .run(sidHash, accountId, csrfToken, now, now + SESSION_TTL_MS);
  return { sid, sidHash, account_id: accountId, csrf_token: csrfToken, expires_at: now + SESSION_TTL_MS };
}
function safeAccount(account) {
  if (!account) return null;
  return {
    id: account.id,
    handle: account.handle,
    email: account.email,
    createdAt: account.created_at,
    minecraftLinked: Boolean(account.minecraft_uuid),
    minecraftUuid: account.minecraft_uuid || null,
    minecraftUsername: account.minecraft_username || null
  };
}
function accountForSession(session) {
  if (!session || !session.account_id) return null;
  return db.prepare('SELECT id, handle, email, created_at, minecraft_uuid, minecraft_username FROM accounts WHERE id = ?').get(session.account_id) || null;
}
app.use((req, res, next) => {
  const cookies = parseCookies(req.headers.cookie);
  const rawSid = cookies[COOKIE_NAME];
  if (rawSid && /^[a-f0-9]{64}$/.test(rawSid)) {
    const record = db.prepare('SELECT * FROM browser_sessions WHERE sid_hash = ?').get(sha256(rawSid));
    if (record && record.expires_at > Date.now()) req.sessionRecord = record;
    else if (record) db.prepare('DELETE FROM browser_sessions WHERE sid_hash = ?').run(record.sid_hash);
  }
  next();
});
function csrfRequired(req, res, next) {
  const supplied = req.get('X-CSRF-Token') || '';
  const stored = req.sessionRecord?.csrf_token || '';
  if (!stored || !constantTimeEqual(supplied, stored)) return res.status(403).json({ error: 'Your session expired. Refresh the page and try again.' });
  next();
}
function authRequired(req, res, next) {
  if (!req.sessionRecord?.account_id) return res.status(401).json({ error: 'Please sign in first.' });
  req.account = accountForSession(req.sessionRecord);
  if (!req.account) return res.status(401).json({ error: 'Please sign in again.' });
  next();
}
const rateState = new Map();
function rateLimit({ limit = 10, windowMs = 10 * 60 * 1000 } = {}) {
  return (req, res, next) => {
    const key = `${req.ip || req.socket.remoteAddress}:${req.path}`;
    const now = Date.now();
    let value = rateState.get(key);
    if (!value || value.until < now) value = { count: 0, until: now + windowMs };
    value.count += 1;
    rateState.set(key, value);
    if (rateState.size > 5000) for (const [k, v] of rateState) if (v.until < now) rateState.delete(k);
    if (value.count > limit) return res.status(429).json({ error: 'Too many attempts. Please wait a few minutes and try again.' });
    next();
  };
}
function issueFreshSession(res, accountId) {
  const session = newSession(accountId);
  setSessionCookie(res, session.sid);
  return session;
}
function pluginAuth(req, res, next) {
  if (!PLUGIN_SECRET || PLUGIN_SECRET === 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET') {
    return res.status(503).json({ error: 'Website linking is not configured by the server owner.' });
  }
  if (!constantTimeEqual(req.get('X-CandySMP-Plugin-Key'), PLUGIN_SECRET)) {
    return res.status(401).json({ error: 'Plugin authentication failed.' });
  }
  next();
}
const codeAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function makeCode() {
  let result = '';
  for (let i = 0; i < 8; i++) result += codeAlphabet[crypto.randomInt(codeAlphabet.length)];
  return result;
}
function validUuid(uuid) {
  return typeof uuid === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(uuid);
}

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'candysmp-account-portal' }));
app.get('/api/csrf', (req, res) => {
  if (req.sessionRecord) return res.json({ csrfToken: req.sessionRecord.csrf_token });
  const session = newSession(null);
  setSessionCookie(res, session.sid);
  req.sessionRecord = session;
  res.json({ csrfToken: session.csrf_token });
});
app.get('/api/session', (req, res) => {
  const account = accountForSession(req.sessionRecord);
  res.json({ user: safeAccount(account), csrfToken: req.sessionRecord?.csrf_token || null });
});
app.post('/api/register', rateLimit({ limit: 8 }), csrfRequired, async (req, res) => {
  const handle = String(req.body?.handle || '').trim();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!/^[A-Za-z0-9_]{3,16}$/.test(handle)) return res.status(400).json({ error: 'Username must be 3–16 characters: letters, numbers, or underscores.' });
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 10 || password.length > 200) return res.status(400).json({ error: 'Password must be at least 10 characters long.' });
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const createdAt = new Date().toISOString();
    const result = db.prepare('INSERT INTO accounts (handle, email, password_hash, created_at) VALUES (?, ?, ?, ?)').run(handle, email, passwordHash, createdAt);
    if (req.sessionRecord) db.prepare('DELETE FROM browser_sessions WHERE sid_hash = ?').run(req.sessionRecord.sid_hash);
    const session = issueFreshSession(res, Number(result.lastInsertRowid));
    const account = accountForSession(session);
    return res.status(201).json({ user: safeAccount(account), csrfToken: session.csrf_token });
  } catch (err) {
    if (String(err.code || '').includes('SQLITE_CONSTRAINT')) return res.status(409).json({ error: 'That website username or email is already registered.' });
    console.error('Registration failed:', err);
    return res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});
app.post('/api/login', rateLimit({ limit: 10 }), csrfRequired, async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const account = db.prepare('SELECT * FROM accounts WHERE email = ?').get(email);
  const matches = account ? await bcrypt.compare(password, account.password_hash) : false;
  if (!matches) return res.status(401).json({ error: 'Email or password is incorrect.' });
  if (req.sessionRecord) db.prepare('DELETE FROM browser_sessions WHERE sid_hash = ?').run(req.sessionRecord.sid_hash);
  const session = issueFreshSession(res, account.id);
  return res.json({ user: safeAccount(accountForSession(session)), csrfToken: session.csrf_token });
});
app.post('/api/logout', csrfRequired, (req, res) => {
  if (req.sessionRecord) db.prepare('DELETE FROM browser_sessions WHERE sid_hash = ?').run(req.sessionRecord.sid_hash);
  const session = issueFreshSession(res, null);
  res.json({ ok: true, user: null, csrfToken: session.csrf_token });
});
app.post('/api/account/link-code', csrfRequired, authRequired, (req, res) => {
  db.prepare('DELETE FROM link_codes WHERE expires_at <= ? OR account_id = ?').run(Date.now(), req.account.id);
  let code = makeCode();
  let codeHash = sha256(code);
  while (db.prepare('SELECT 1 FROM link_codes WHERE code_hash = ?').get(codeHash)) { code = makeCode(); codeHash = sha256(code); }
  const now = Date.now();
  db.prepare('INSERT INTO link_codes (code_hash, account_id, created_at, expires_at) VALUES (?, ?, ?, ?)').run(codeHash, req.account.id, now, now + CODE_TTL_MS);
  res.json({ code, expiresAt: now + CODE_TTL_MS, instructions: `/website link ${code}` });
});
app.post('/api/account/unlink', csrfRequired, authRequired, (req, res) => {
  db.prepare('UPDATE accounts SET minecraft_uuid = NULL, minecraft_username = NULL WHERE id = ?').run(req.account.id);
  db.prepare('DELETE FROM link_codes WHERE account_id = ?').run(req.account.id);
  res.json({ ok: true, message: 'Minecraft account disconnected.' });
});

app.post('/api/minecraft/link', pluginAuth, (req, res) => {
  const code = String(req.body?.code || '').trim().toUpperCase();
  const uuid = String(req.body?.uuid || '').trim().toLowerCase();
  const username = String(req.body?.username || '').trim();
  if (!/^[A-Z2-9]{8}$/.test(code)) return res.status(400).json({ error: 'That link code is invalid or expired.' });
  if (!validUuid(uuid) || !/^[A-Za-z0-9_]{1,16}$/.test(username)) return res.status(400).json({ error: 'Invalid Minecraft account details.' });
  const transaction = db.transaction(() => {
    const codeRow = db.prepare('SELECT * FROM link_codes WHERE code_hash = ?').get(sha256(code));
    if (!codeRow) return { status: 400, error: 'That link code is invalid or has already been used.' };
    if (codeRow.expires_at <= Date.now()) {
      db.prepare('DELETE FROM link_codes WHERE code_hash = ?').run(codeRow.code_hash);
      return { status: 400, error: 'That link code expired. Generate a new code on the website.' };
    }
    const account = db.prepare('SELECT id, handle, minecraft_uuid FROM accounts WHERE id = ?').get(codeRow.account_id);
    if (!account) return { status: 400, error: 'Website account not found.' };
    if (account.minecraft_uuid && account.minecraft_uuid.toLowerCase() !== uuid) return { status: 409, error: 'This website profile already has a different Minecraft account linked. Unlink it first.' };
    const other = db.prepare('SELECT id FROM accounts WHERE minecraft_uuid = ?').get(uuid);
    if (other && other.id !== account.id) return { status: 409, error: 'That Minecraft account is already linked to another website profile.' };
    db.prepare('UPDATE accounts SET minecraft_uuid = ?, minecraft_username = ? WHERE id = ?').run(uuid, username, account.id);
    db.prepare('DELETE FROM link_codes WHERE account_id = ?').run(account.id);
    return { status: 200, ok: true, message: `Minecraft account ${username} linked to website profile ${account.handle}.` };
  });
  try {
    const result = transaction();
    return res.status(result.status).json(result);
  } catch (err) {
    console.error('Minecraft linking failed:', err);
    return res.status(500).json({ error: 'Unable to link the Minecraft account right now.' });
  }
});
app.post('/api/minecraft/status', pluginAuth, (req, res) => {
  const uuid = String(req.body?.uuid || '').trim().toLowerCase();
  if (!validUuid(uuid)) return res.status(400).json({ error: 'Invalid Minecraft UUID.' });
  const account = db.prepare('SELECT handle, minecraft_username FROM accounts WHERE minecraft_uuid = ?').get(uuid);
  res.json({ ok: true, linked: Boolean(account), websiteHandle: account?.handle || null, minecraftUsername: account?.minecraft_username || null });
});
app.post('/api/minecraft/unlink', pluginAuth, (req, res) => {
  const uuid = String(req.body?.uuid || '').trim().toLowerCase();
  if (!validUuid(uuid)) return res.status(400).json({ error: 'Invalid Minecraft UUID.' });
  const result = db.prepare('UPDATE accounts SET minecraft_uuid = NULL, minecraft_username = NULL WHERE minecraft_uuid = ?').run(uuid);
  res.json({ ok: true, unlinked: result.changes > 0, message: result.changes ? 'Minecraft account disconnected from the website.' : 'This Minecraft account is not linked.' });
});

app.use(express.static(path.join(__dirname, 'public'), { etag: true, maxAge: NODE_ENV === 'production' ? '1h' : 0 }));
app.use('/api', (req, res) => res.status(404).json({ error: 'API route not found.' }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

const cleanupTimer = setInterval(() => {
  const now = Date.now();
  db.prepare('DELETE FROM browser_sessions WHERE expires_at <= ?').run(now);
  db.prepare('DELETE FROM link_codes WHERE expires_at <= ?').run(now);
}, 60 * 60 * 1000);
cleanupTimer.unref();
app.listen(PORT, '0.0.0.0', () => {
  console.log(`CandySMP account portal listening on port ${PORT}`);
  if (!PLUGIN_SECRET || PLUGIN_SECRET === 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET') console.warn('PLUGIN_SECRET is not configured. Minecraft account linking will stay disabled until you set it.');
});
